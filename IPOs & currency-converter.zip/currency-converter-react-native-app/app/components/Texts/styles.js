import EStyleSheet from 'react-native-extended-stylesheet';

const styles = EStyleSheet.create({
  smallText: {
    color: '$white',
    textAlign: 'center',
    fontSize: 12,
  }
});

export default styles;
